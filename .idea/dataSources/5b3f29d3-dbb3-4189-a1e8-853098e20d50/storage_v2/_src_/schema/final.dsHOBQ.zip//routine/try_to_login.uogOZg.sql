CREATE FUNCTION try_to_login(myemail VARCHAR(256), pass VARCHAR(45))
  RETURNS INT
  BEGIN
	DECLARE var INT DEFAULT 0;
    SELECT count(*) from users WHERE users.email = myemail limit 1 into var;
    if(var = 0) then return 1; end if;
	SELECT count(*) from users WHERE users.email = myemail and users.password = pass limit 1 into var;
    if(var = 0) then return 2; end if;
    return 0;
END;

