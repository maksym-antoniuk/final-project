CREATE PROCEDURE get_portfolio(IN user_id INT)
  BEGIN
	DECLARE var VARCHAR(30);
    SELECT role from users where id = user_id into var;
    if(var = 'driver') then
    SELECT name, surname, email, phone, role, timestampdiff(DAY, datareg, now()) as days, sum(if(accept = 'yes', 1,0)) as journeys FROM users
	INNER JOIN cars ON users.id = id_driver
    LEFT OUTER JOIN journeys_has_cars ON cars.id = cars_id
	WHERE users.id =  user_id;
    else 
    SELECT name, surname, email, phone, role, timestampdiff(DAY, datareg, now()) as days, count(id_manager) as journeys FROM users
	INNER JOIN journeys ON users.id = id_manager WHERE users.id = 1 ;
    end if;
END;

