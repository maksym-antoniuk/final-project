CREATE TRIGGER users_BEFORE_INSERT
  BEFORE INSERT
  ON users
  FOR EACH ROW
  BEGIN
	set new.password = MD5(new.password);
END;

